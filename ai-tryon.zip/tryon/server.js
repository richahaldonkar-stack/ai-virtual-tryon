// Backend proxy: keeps the FASHN API key off the browser and chains garments onto one person image.
import express from 'express';
import { unzipSync } from 'fflate';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dir = path.dirname(fileURLToPath(import.meta.url));
const PUB = path.join(__dir, 'public');
const KEY = process.env.FASHN_API_KEY;
const MODEL = process.env.FASHN_MODEL || 'tryon-v1.6';
const MODE = process.env.FASHN_MODE || 'balanced';
const LIMIT = +process.env.RATE_LIMIT || 8;
const BASE = 'https://api.fashn.ai/v1';
const load = f => JSON.parse(fs.readFileSync(path.join(__dir, f), 'utf8'));
const catalog = load('catalog.json'), models = load('models.json');
// Slot -> FASHN "category". Application order matters: base layer first, jacket last.
const CATEGORY = { top: 'tops', jacket: 'tops', bottom: 'bottoms', dress: 'one-pieces' };
const ORDER = ['dress', 'top', 'bottom', 'jacket'];

class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }
const sleep = ms => new Promise(r => setTimeout(r, ms));

async function fashn(p, opt = {}) {
  const r = await fetch(BASE + p, { ...opt, headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + KEY } });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) {
    const m = j?.error?.message || j?.message || (typeof j?.error === 'string' ? j.error : '');
    console.error('FASHN', r.status, JSON.stringify(j).slice(0, 300));
    throw new HttpError(r.status === 429 ? 429 : 502, m || 'The try-on service returned an error.');
  }
  return j;
}

async function runStep(model_image, garment_image, category) {
  const { id } = await fashn('/run', { method: 'POST', body: JSON.stringify({
    model_name: MODEL, inputs: { model_image, garment_image, category, mode: MODE,
      ...(process.env.FASHN_USE_SEED === 'true' ? { seed: Math.floor(Math.random() * 4294967295) } : {}) } }) });
  for (let i = 0; i < 60; i++) {
    await sleep(2000);
    const s = await fashn('/status/' + id);
    if (s.status === 'completed') return s.output[0];
    if (s.status === 'failed') throw new HttpError(422, s.error?.message || 'The AI could not fit this garment on that photo. Try a clearer full-body photo.');
  }
  throw new HttpError(504, 'The AI took too long. Please try again.');
}

// Images are read from disk (public/) or fetched, then sent to FASHN as base64 so localhost works too.
async function toDataUrl(src) {
  if (/^https?:\/\//.test(src)) {
    const r = await fetch(src); if (!r.ok) throw new HttpError(502, 'Could not load a catalog image.');
    const type = r.headers.get('content-type') || 'image/png';
    return `data:${type};base64,${Buffer.from(await r.arrayBuffer()).toString('base64')}`;
  }
  const f = path.resolve(PUB, src.replace(/^\/+/, ''));
  if (!f.startsWith(PUB)) throw new HttpError(400, 'Bad image path.');
  const ext = path.extname(f).slice(1).replace('jpg', 'jpeg');
  return `data:image/${ext};base64,${fs.readFileSync(f).toString('base64')}`;
}


// ---- Result handling: the provider may hand back a PNG/JPG/WebP, a data URL, or a ZIP containing the image ----
const sniff = b => {
  if (b.length < 12) return null;
  if (b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4E && b[3] === 0x47) return 'image/png';
  if (b[0] === 0xFF && b[1] === 0xD8 && b[2] === 0xFF) return 'image/jpeg';
  if (b.toString('latin1', 0, 4) === 'RIFF' && b.toString('latin1', 8, 12) === 'WEBP') return 'image/webp';
  if (b[0] === 0x50 && b[1] === 0x4B && (b[2] === 0x03 || b[2] === 0x05)) return 'zip';
  return null;
};
function extractImage(buf) {
  let n = 0, files;
  try {
    files = unzipSync(new Uint8Array(buf), { filter: f => {
      const base = f.name.split('/').pop();
      return !f.name.startsWith('__MACOSX') && !base.startsWith('.') && !f.name.endsWith('/') && f.originalSize <= 25e6 && ++n <= 50;
    } });
  } catch { throw new HttpError(502, 'The AI result was a damaged ZIP file. Please try again.'); }
  let best = null;
  for (const [name, data] of Object.entries(files)) {   // identify images by content, not file extension
    const b = Buffer.from(data), t = sniff(b);
    if (t && t !== 'zip' && (!best || b.length > best.buf.length)) best = { buf: b, type: t, name };
  }
  if (!best) throw new HttpError(422, 'The AI finished, but the ZIP it returned did not contain an image (PNG, JPG or WebP). Please try again.');
  return best;
}
async function fetchImage(src, onStage) {
  let buf;
  if (src.startsWith('data:')) buf = Buffer.from(src.split(',')[1] || '', 'base64');
  else {
    const r = await fetch(src); if (!r.ok) throw new HttpError(502, 'Could not download the generated image.');
    buf = Buffer.from(await r.arrayBuffer());
  }
  let type = sniff(buf);
  if (type === 'zip') { onStage && onStage('extracting'); ({ buf, type } = extractImage(buf)); }
  if (!type) throw new HttpError(502, 'The AI result was not a recognizable image. Please try again.');
  return `data:${type};base64,${buf.toString('base64')}`;
}

const hits = new Map();
function limited(ip) {
  const now = Date.now(), a = (hits.get(ip) || []).filter(t => now - t < 600000);
  if (a.length >= LIMIT) return true; a.push(now); hits.set(ip, a); return false;
}

const app = express();
app.use(express.json({ limit: '12mb' }));
app.use(express.static(PUB));
app.get('/api/catalog', (_, res) => res.json({ items: catalog, models, ready: !!KEY }));

app.post('/api/tryon', async (req, res) => {
  try {
    if (!KEY) throw new HttpError(503, 'The try-on service is not configured yet (missing FASHN_API_KEY).');
    if (limited(req.ip)) throw new HttpError(429, 'Too many try-ons. Please wait a few minutes and try again.');
    const { person, items } = req.body || {};
    let image;
    if (person?.type === 'upload') {
      if (!/^data:image\/(jpeg|png|webp);base64,/.test(person.image || '') || person.image.length > 10e6)
        throw new HttpError(400, 'Please upload a JPG, PNG or WebP photo under 7 MB.');
      image = person.image;
    } else if (person?.type === 'model') {
      const m = models.find(x => x.id === person.id); if (!m) throw new HttpError(400, 'Unknown model.');
      image = await toDataUrl(m.image);
    } else throw new HttpError(400, 'Choose a photo or a model.');

    const picked = (Array.isArray(items) ? items : []).map(id => catalog.find(c => c.id === id));
    if (!picked.length || picked.some(p => !p || p.supported === false || !CATEGORY[p.slot])) throw new HttpError(400, 'Choose at least one supported item.');
    if (picked.some(p => p.slot === 'dress') && picked.some(p => ['top', 'bottom'].includes(p.slot))) throw new HttpError(400, 'A dress replaces tops and bottoms. Pick one or the other.');
    picked.sort((a, b) => ORDER.indexOf(a.slot) - ORDER.indexOf(b.slot));

    // Validation is done: stream progress as newline-delimited JSON so the UI can show real stages.
    res.setHeader('Content-Type', 'application/x-ndjson'); res.setHeader('Cache-Control', 'no-store'); res.flushHeaders();
    const send = o => res.write(JSON.stringify(o) + '\n');
    let current = image;
    for (let i = 0; i < picked.length; i++) {
      send({ stage: 'generating', step: i + 1, total: picked.length });
      const url = await runStep(current, await toDataUrl(picked[i].image), CATEGORY[picked[i].slot]);
      current = await fetchImage(url, st => send({ stage: st }));   // always a real image data URL, never a ZIP
    }
    send({ stage: 'done', image: current }); res.end();
  } catch (e) {
    const msg = e.status ? e.message : 'Something went wrong. Please try again.';
    if (!e.status) console.error(e);
    if (res.headersSent) { res.write(JSON.stringify({ error: msg }) + '\n'); res.end(); }
    else res.status(e.status || 500).json({ error: msg });
  }
});

app.listen(process.env.PORT || 3000, () => console.log(`Try-on studio on http://localhost:${process.env.PORT || 3000}${KEY ? '' : '  (no FASHN_API_KEY set)'}`));
