# AI Virtual Try-On

Real try-on via the FASHN API (model `tryon-v1.6`). The browser never sees your API key; `server.js` proxies the calls.

## Run it
1. Install Node 20.6+ and run `npm install`.
2. Copy `.env.example` to `.env` and set `FASHN_API_KEY` (create one at fashn.ai, Developer section; calls cost credits).
3. `npm start`, then open http://localhost:3000.

## Add it to your existing site
- Copy `public/tryon.css` and `public/tryon.js` to your site and include them on any page.
- Add `data-tryon` to any button, e.g. `<button class="tp-cta" data-tryon>Try It On with AI</button>`.
- If the backend lives on another domain, use `<script src="tryon.js" data-api="https://api.yoursite.com" defer>` and add CORS headers (`Access-Control-Allow-Origin` for your site) to `server.js`.
- Deploy `server.js` anywhere that runs Node and allows requests of ~60 s (a try-on can chain several garments). Serverless platforms with 10 s limits will time out.

## What you configure
- `catalog.json`: your products. `slot` is `top`, `bottom`, `dress`, `jacket`, `shoes` or `accessory`; `image` is a clean garment photo (flat lay or ghost mannequin, plain background works best). Replace the demo items.
- `models.json`: your AI/studio models. The demo uses six placeholder photos; swap in licensed images with the diversity of body types, poses and styles you want. Front-facing, full-body, plain background gives the best results.
- `.env`: `FASHN_MODE` (`performance`, `balanced`, `quality`) trades speed for quality; `RATE_LIMIT` caps tries per IP.

## How it works
Garments are applied in order (dress, or top then bottom, then jacket). Each result becomes the input for the next garment, so one click produces the full outfit. The user's original photo is kept for the side-by-side view; previews stack in a history strip so they can try more outfits without re-uploading.

## Known limits (be upfront with users)
- `tryon-v1.6` supports tops, bottoms and one-pieces only. Footwear and accessories are shown as disabled ("Soon"). FASHN's newer Try-On Max endpoint lists shoes, hats, jewelry and bags, but I didn't confirm its request format, so check docs.fashn.ai and adapt `runStep()` in `server.js`.
- Realism depends on input photos. Crossed arms, baggy clothes, or cropped photos lower quality.
- Jackets are applied as a second "tops" layer, so results over another top vary.
- Photos contain personal data: keep the consent checkbox, add a line to your privacy policy naming the AI provider, and don't log request bodies. This code does not store photos.
- Output links from FASHN expire; the server returns the image itself so downloads keep working.
