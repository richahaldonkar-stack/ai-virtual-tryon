/* AI Virtual Try-On widget. Add to any page:
   <link rel="stylesheet" href="/tryon.css"><script src="/tryon.js" defer></script>
   then put data-tryon on any button. Set data-api="https://your-api" on the script tag if the backend is on another origin. */
(() => {
  const API = (document.currentScript && document.currentScript.dataset.api) || '';
  const SLOTS = [['top', 'Tops'], ['bottom', 'Bottoms'], ['dress', 'Dresses'], ['jacket', 'Jackets'], ['shoes', 'Footwear'], ['accessory', 'Accessories']];
  const $ = (s, r = root) => r.querySelector(s);
  const el = (t, props = {}, kids = []) => { const e = Object.assign(document.createElement(t), props); e.append(...kids); return e; };
  let data = null, busy = false, timer = 0, opener = null;
  const st = { src: 'upload', photo: null, model: null, sel: {}, slot: 'top', hist: [], view: -1, ok: false };

  const root = el('div', { className: 'tp', hidden: true });
  root.setAttribute('role', 'dialog'); root.setAttribute('aria-modal', 'true'); root.setAttribute('aria-label', 'AI Virtual Try-On');
  root.innerHTML = `<div class="tp-top"><h2>AI Try-On Studio</h2><button class="tp-x" data-x aria-label="Close">×</button></div>
  <div class="tp-body"><div class="tp-side">
   <div class="tp-step"><h3>1. Who is trying it on?</h3><p>Use your own photo or preview on one of our models.</p>
    <div class="tp-seg"><button data-src="upload" aria-pressed="true">My photo</button><button data-src="model" aria-pressed="false">AI models</button></div>
    <div data-upload><label class="tp-drop" data-drop><input type="file" accept="image/jpeg,image/png,image/webp" hidden data-file><span data-dropmsg><b>Upload a full-body photo</b><br><small>Click or drag a JPG, PNG or WebP here</small></span></label>
     <ul class="tp-tips"><li>Stand straight, head to toe, facing the camera</li><li>Good light, plain background, arms slightly away from your body</li><li>Wear fitted clothes so the new outfit sits naturally</li></ul>
     <label class="tp-consent"><input type="checkbox" data-consent> I agree to send this photo to our AI provider to generate the preview. It is not stored by this site.</label></div>
    <div data-models class="tp-grid" hidden></div></div>
   <div class="tp-step"><h3>2. Pick the outfit</h3><p>Choose one piece per category. Mix and match.</p><div class="tp-tabs" data-tabs></div><div class="tp-grid" data-items></div></div>
   <div class="tp-step"><button class="tp-go" data-go>Generate my look</button><p class="tp-hint" data-hint></p></div></div>
  <div class="tp-main"><div class="tp-welcome" data-welcome><h3>Your fitting room</h3><ol><li>Upload a photo or choose a model.</li><li>Pick tops, bottoms, a dress or a jacket.</li><li>Press Generate. It takes about 10–30 seconds.</li><li>Change the outfit and generate again. No re-upload needed.</li></ol></div>
   <div class="tp-cmp" data-cmp hidden><div class="tp-pane"><b>Original</b><div><img data-orig alt="Original photo"></div></div><div class="tp-pane"><b>With AI</b><div><img data-res alt="AI outfit preview"><div class="tp-load" data-load hidden><div class="tp-ring"></div><div data-msg role="status" aria-live="polite">Preparing…</div></div></div></div></div>
   <div class="tp-err" data-err role="alert" hidden></div>
   <div class="tp-bar" data-bar hidden><button class="tp-dl" data-dl>Download</button><button class="tp-regen" data-regen>Regenerate</button><span class="tp-hint" data-cap></span></div><div class="tp-hist" data-hist></div></div></div>`;
  document.body.append(root);

  async function ensureData() {
    if (data) return;
    try { const r = await fetch(API + '/api/catalog'); if (!r.ok) throw 0; data = await r.json(); }
    catch { data = { items: [], models: [], ready: false, offline: true }; }
    st.ok = data.ready; drawModels(); drawTabs(); drawItems(); update();
  }
  function open(e) { opener = e; root.hidden = false; document.body.style.overflow = 'hidden'; $('[data-x]').focus(); ensureData(); }
  function close() { root.hidden = true; document.body.style.overflow = ''; opener && opener.focus && opener.focus(); }
  document.addEventListener('click', e => { const b = e.target.closest('[data-tryon]'); if (b) { e.preventDefault(); open(b); } });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && !root.hidden) close(); });
  $('[data-x]').onclick = close;

  const pressed = (b, on) => b.setAttribute('aria-pressed', on);
  root.querySelectorAll('[data-src]').forEach(b => b.onclick = () => {
    st.src = b.dataset.src; root.querySelectorAll('[data-src]').forEach(x => pressed(x, x === b));
    $('[data-upload]').hidden = st.src !== 'upload'; $('[data-models]').hidden = st.src !== 'model'; update();
  });
  function drawModels() {
    const g = $('[data-models]'); g.textContent = '';
    data.models.forEach(m => { const b = el('button', { className: 'tp-card', title: m.desc || '' }, [el('img', { src: m.image, alt: m.name, loading: 'lazy' }), el('span', { textContent: m.name + (m.desc ? ' · ' + m.desc : '') })]);
      pressed(b, st.model === m.id); b.onclick = () => { st.model = m.id; drawModels(); update(); }; g.append(b); });
  }
  function drawTabs() {
    const t = $('[data-tabs]'); t.textContent = '';
    SLOTS.forEach(([k, n]) => { const c = data.items.filter(i => i.slot === k).length;
      const b = el('button', { textContent: n }, [el('i', { textContent: st.sel[k] ? '✓' : '' })]); pressed(b, st.slot === k);
      b.onclick = () => { st.slot = k; drawTabs(); drawItems(); }; t.append(b); });
  }
  function drawItems() {
    const g = $('[data-items]'); g.textContent = '';
    const list = data.items.filter(i => i.slot === st.slot);
    if (!list.length) { g.append(el('div', { className: 'tp-empty', style: 'grid-column:1/-1', textContent: data.offline ? 'Could not reach the try-on server. Start it with npm start.' : 'No items in this category yet. Add them to catalog.json.' })); return; }
    list.forEach(i => { const off = i.supported === false;
      const b = el('button', { className: 'tp-card', disabled: off, title: off ? 'Needs an image-edit provider (see README)' : i.name }, [el('img', { src: i.image, alt: i.name, loading: 'lazy' }), el('span', { textContent: i.name }), ...(off ? [el('em', { textContent: 'Soon' })] : [])]);
      pressed(b, st.sel[i.slot] === i.id);
      b.onclick = () => { const on = st.sel[i.slot] === i.id; st.sel[i.slot] = on ? null : i.id;
        if (!on && i.slot === 'dress') { st.sel.top = st.sel.bottom = null; } if (!on && (i.slot === 'top' || i.slot === 'bottom')) st.sel.dress = null;
        drawTabs(); drawItems(); update(); };
      g.append(b); });
  }
  const chosen = () => Object.values(st.sel).filter(Boolean);
  function update() {
    const person = st.src === 'upload' ? !!st.photo && $('[data-consent]').checked : !!st.model;
    let hint = '';
    if (!st.ok) hint = data && data.offline ? 'Try-on server not reachable.' : 'Try-on is not configured yet (missing API key).';
    else if (!person) hint = st.src === 'upload' ? (st.photo ? 'Tick the consent box to continue.' : 'Upload a photo to start.') : 'Choose a model to start.';
    else if (!chosen().length) hint = 'Pick at least one item.';
    $('[data-go]').disabled = busy || !!hint; $('[data-hint]').textContent = hint;
  }
  $('[data-consent]').onchange = update;

  function prep(file) {
    return new Promise((res, rej) => { const u = URL.createObjectURL(file), im = new Image();
      im.onload = () => { const s = Math.min(1, 1280 / Math.max(im.width, im.height)), c = el('canvas', { width: Math.round(im.width * s), height: Math.round(im.height * s) });
        c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); URL.revokeObjectURL(u); res(c.toDataURL('image/jpeg', .9)); };
      im.onerror = () => rej(new Error('Could not read that image. Please use a JPG or PNG.')); im.src = u; });
  }
  async function pickFile(f) {
    if (!f) return; try { st.photo = await prep(f); } catch (e) { return showErr(e.message); }
    showErr(''); const m = $('[data-dropmsg]'); m.textContent = ''; m.append(el('img', { src: st.photo, alt: 'Your photo' }), el('br'), el('small', { textContent: 'Click to change photo' })); update();
  }
  $('[data-file]').onchange = e => pickFile(e.target.files[0]);
  const drop = $('[data-drop]');
  ['dragenter', 'dragover'].forEach(n => drop.addEventListener(n, e => { e.preventDefault(); drop.classList.add('over'); }));
  ['dragleave', 'drop'].forEach(n => drop.addEventListener(n, e => { e.preventDefault(); drop.classList.remove('over'); }));
  drop.addEventListener('drop', e => pickFile(e.dataTransfer.files[0]));

  const showErr = m => { const e = $('[data-err]'); e.textContent = m; e.hidden = !m; };
  const origSrc = () => st.src === 'upload' ? st.photo : (data.models.find(m => m.id === st.model) || {}).image;
  function show(i) {
    st.view = i; const h = st.hist[i]; $('[data-orig]').src = h.orig; $('[data-res]').src = h.img;
    $('[data-cap]').textContent = h.names;
    $('[data-bar]').hidden = false; drawHist();
  }
  function drawHist() {
    const w = $('[data-hist]'); w.textContent = '';
    st.hist.forEach((h, i) => { const b = el('button', { title: h.names }, [el('img', { src: h.img, alt: 'Preview ' + (i + 1) })]); pressed(b, i === st.view); b.onclick = () => show(i); w.append(b); });
  }
  const MSGS = ['Reading your photo…', 'Fitting the garment…', 'Smoothing folds and fabric…', 'Adding finishing touches…', 'Almost there…'];
  $('[data-res]').onerror = () => showErr('The preview image could not be displayed. Try regenerating.');
  async function run() {
    if (busy) return; busy = true; showErr(''); update(); $('[data-regen]').disabled = true;
    const orig = origSrc(), names = chosen().map(id => data.items.find(i => i.id === id).name).join(' + ');
    $('[data-welcome]').hidden = true; $('[data-cmp]').hidden = false; $('[data-orig]').src = orig;
    $('[data-cmp]').scrollIntoView({ behavior: 'smooth', block: 'start' });   // mobile: bring the preview into view
    const L = $('[data-load]'), M = $('[data-msg]'); L.hidden = false; let n = 0, locked = false; M.textContent = MSGS[0];
    timer = setInterval(() => { if (!locked) { n = Math.min(n + 1, MSGS.length - 1); M.textContent = MSGS[n]; } }, 4000);
    try {
      const r = await fetch(API + '/api/tryon', { method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ person: st.src === 'upload' ? { type: 'upload', image: st.photo } : { type: 'model', id: st.model }, items: chosen() }) });
      if (!r.ok) { const j = await r.json().catch(() => ({})); throw new Error(j.error || 'Something went wrong. Please try again.'); }
      const rd = r.body.getReader(), dec = new TextDecoder(); let buf = '', img = null;
      for (;;) {
        const { done, value } = await rd.read(); if (done) break; buf += dec.decode(value, { stream: true });
        let k; while ((k = buf.indexOf('\n')) >= 0) {
          const line = buf.slice(0, k).trim(); buf = buf.slice(k + 1); if (!line) continue;
          const m = JSON.parse(line); if (m.error) throw new Error(m.error);
          if (m.stage === 'generating') { locked = false; if (m.total > 1) M.textContent = `Generating piece ${m.step} of ${m.total}…`; }
          else if (m.stage === 'extracting') { locked = true; M.textContent = 'Unpacking the generated image…'; }
          else if (m.stage === 'done') img = m.image;
        }
      }
      if (!img || !/^data:image\/(png|jpeg|webp);base64,/.test(img)) throw new Error('The AI did not return a usable image. Please try again.');
      st.hist.push({ img, orig, names }); show(st.hist.length - 1);
    } catch (e) { showErr(e.message || 'Network error. Please try again.'); if (st.hist.length) show(st.view); }
    finally { clearInterval(timer); L.hidden = true; busy = false; update(); $('[data-regen]').disabled = false; }
  }
  $('[data-go]').onclick = run; $('[data-regen]').onclick = run;
  $('[data-dl]').onclick = async () => {
    const h = st.hist[st.view]; if (!h) return;
    const blob = await (await fetch(h.img)).blob(), ext = blob.type.split('/')[1].replace('jpeg', 'jpg');
    const file = new File([blob], 'outfit-preview-' + (st.view + 1) + '.' + ext, { type: blob.type });
    if (/iPhone|iPad|iPod/.test(navigator.userAgent) && navigator.canShare && navigator.canShare({ files: [file] })) { try { await navigator.share({ files: [file] }); return; } catch {} }   // iOS ignores download attr
    const u = URL.createObjectURL(blob), a = el('a', { href: u, download: file.name }); document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(u), 1000);
  };
})();
